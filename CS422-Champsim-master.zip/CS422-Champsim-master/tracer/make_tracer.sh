export PIN_ROOT=/home/grads/c/cienlux/task/pin-3.2-81205-gcc-linux
mkdir -p obj-intel64
make obj-intel64/champsim_tracer.so
